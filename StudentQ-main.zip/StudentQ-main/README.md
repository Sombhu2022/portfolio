## StudentQ

## Final Year Project
### README file managed by Saniyaj Mallik.

### Group Members 
    1. Saniyaj Mallik
    2. Soumen Samanta
    3. Pritam Paul
    4. Sombhu Das
   
### Tech stack of this project
  - Python
  - Django
  - PostgreSQL
  - HTML
  - CSS
  - JavaScript
 
### 17/02/2023 (Project Start)
  - Designs (Saniyaj, Sombhu & Pritam)

### 18 /02/2023
  - designs (Sombhu & Pritam)

### 19/02/2023 (user account creation System complete)
  - By Saniyaj Mallik
  
